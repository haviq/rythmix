#!/bin/bash
# Rythmix resolver — installer utk VPS (Ubuntu/Debian, root).
# Paste di VPS:  bash INSTALL.sh
# Hasil: systemd service "rythmix-resolver" di port 8790 + bgutil POT server di 127.0.0.1:4416
set -euo pipefail

DIR=/opt/rythmix-resolver
KEY="${RM_KEY:-a019e9b4b06dad51a10286d4}"   # ganti kalau mau: RM_KEY=xxx bash INSTALL.sh
PORT=8790
BG_VER=2.0.0

[ "$(id -u)" = 0 ] || { echo "run sebagai root"; exit 1; }
cd "$(dirname "$0")"

echo "==> [1/6] deps"
apt-get update -qq
apt-get install -y -qq python3-venv python3-pip build-essential curl ca-certificates >/dev/null

echo "==> [2/6] venv + yt-dlp + POT plugin + node"
mkdir -p "$DIR"
cp -f resolver.py "$DIR/resolver.py"
[ -d "$DIR/.venv" ] || python3 -m venv "$DIR/.venv"
"$DIR/.venv/bin/pip" -q install --upgrade pip
"$DIR/.venv/bin/pip" -q install "yt-dlp[default]==2026.08.19" bgutil-ytdlp-pot-provider==2.0.0 nodejs-wheel-binaries

NODE="$(command -v node || true)"
if [ -z "$NODE" ]; then
  NODE="$("$DIR/.venv/bin/python" -c 'import nodejs_wheel,os;print(os.path.join(os.path.dirname(nodejs_wheel.__file__),"bin","node"))' 2>/dev/null || true)"
fi
[ -n "$NODE" ] && [ -x "$NODE" ] || { echo "node gak ketemu"; exit 1; }
echo "    node: $($NODE --version)"

echo "==> [3/6] bgutil POT server (port 4416, localhost only)"
BGD=/opt/bgutil-pot
if [ ! -d "$BGD/build" ]; then
  mkdir -p "$BGD"
  curl -sL -o /tmp/bgsrc.tgz "https://github.com/Brainicism/bgutil-ytdlp-pot-provider/archive/refs/tags/$BG_VER.tar.gz"
  tar xzf /tmp/bgsrc.tgz -C /tmp
  cp -r /tmp/bgutil-ytdlp-pot-provider-$BG_VER/server/* "$BGD/"
  cd "$BGD"
  PATH="$(dirname "$NODE"):$PATH" npm install --silent --no-fund --no-audit
  PATH="$(dirname "$NODE"):$PATH" npx tsc
  cd "$DIR"
fi

echo "==> [4/6] systemd"
cat >/etc/systemd/system/bgutil-pot.service <<EOF
[Unit]
Description=bgutil PO Token server
After=network.target
[Service]
WorkingDirectory=$BGD
ExecStart=$NODE build/main.js --port 4416 --host 127.0.0.1
Restart=always
RestartSec=3
MemoryMax=300M
[Install]
WantedBy=multi-user.target
EOF

cat >/etc/systemd/system/rythmix-resolver.service <<EOF
[Unit]
Description=Rythmix stream resolver
After=network.target bgutil-pot.service
Requires=bgutil-pot.service
[Service]
WorkingDirectory=$DIR
Environment=RM_PORT=$PORT
Environment=RM_KEY=$KEY
Environment=RM_BGUTIL=http://127.0.0.1:4416
ExecStart=$DIR/.venv/bin/python resolver.py
Restart=always
RestartSec=3
MemoryMax=400M
[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable --now bgutil-pot rythmix-resolver

echo "==> [5/6] firewall"
if command -v ufw >/dev/null 2>&1; then ufw allow $PORT/tcp >/dev/null || true; fi
echo "    (1Panel? buka port $PORT di Security → Firewall ALSO panel cloud provider)"

echo "==> [6/6] tes (cold resolve, butuh ~5-20 detik)"
sleep 6
curl -s "http://127.0.0.1:4416/ping" && echo " <- bgutil ok"
time curl -s "http://127.0.0.1:$PORT/resolve?videoId=kJQP7kiw5Fk&key=$KEY" | head -c 300; echo
echo "SELESAI. Base URL utk APK: http://$(curl -s -m 5 ifconfig.me || hostname -I | awk '{print $1}'):$PORT  key: $KEY"
