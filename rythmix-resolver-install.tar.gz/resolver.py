#!/usr/bin/env python3
"""Rythmix resolver — yt-dlp server-side, HP dapat googlevideo URL langsung.
Audio TIDAK lewat sini (HP stream direct dari Google). RAM ~150MB.
Env: RM_PORT (8790), RM_KEY (opsional), RM_BGUTIL (http://bgutil:4416).
"""
import json, os, threading, time
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs

from yt_dlp import YoutubeDL

PORT = int(os.environ.get("RM_PORT", "8790"))
API_KEY = os.environ.get("RM_KEY", "")
BGUTIL = os.environ.get("RM_BGUTIL", "http://bgutil:4416")
CACHE_TTL = 5 * 3600
CACHE_MAX = 400

_cache = {}  # vid -> (url, title, artist, duration, exp)
_lock = threading.Lock()


def _ydl():
    opts = {
        "quiet": True, "no_warnings": True, "skip_download": True,
        "format": "bestaudio[ext=m4a]/bestaudio/best",
        "cachedir": False, "socket_timeout": 20,
        "extractor_args": {
            "youtube": {"player_client": ["tv", "web"]},
            "youtubepot-bgutilhttp": {"base_url": [BGUTIL]},
        },
    }
    if os.path.exists("cookies.txt"):
        opts["cookiefile"] = "cookies.txt"
    return YoutubeDL(opts)


def resolve(vid: str):
    now = time.time()
    with _lock:
        hit = _cache.get(vid)
        if hit and hit[4] > now:
            return hit[:4]
    with _ydl() as y:
        info = y.extract_info(f"https://www.youtube.com/watch?v={vid}", download=False)
    fmts = info.get("formats") or []
    fmt = next((f for f in reversed(fmts) if f.get("url") and (f.get("acodec") or "none") != "none"), None)
    url = fmt["url"] if fmt else info.get("url")
    if not url:
        raise RuntimeError("no stream url")
    out = (url, info.get("title") or vid, info.get("uploader") or "", int(info.get("duration") or 0))
    with _lock:
        _cache[vid] = out + (now + CACHE_TTL,)
        if len(_cache) > CACHE_MAX:
            for k, v in sorted(_cache.items(), key=lambda kv: kv[1][4])[:50]:
                if v[4] <= now:
                    _cache.pop(k, None)
    return out


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, obj):
        b = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if API_KEY and q.get("key", [""])[0] != API_KEY:
            return self._send(401, {"error": "bad key"})
        if u.path == "/health":
            return self._send(200, {"ok": True, "cache": len(_cache)})
        if u.path in ("/resolve", "/prewarm"):
            vid = (q.get("videoId") or q.get("v") or [""])[0]
            if len(vid) != 11:
                return self._send(400, {"error": "bad videoId"})
            t0 = time.time()
            try:
                url, title, artist, dur = resolve(vid)
            except Exception as e:
                return self._send(502, {"error": str(e)[:200]})
            return self._send(200, {"url": url, "title": title, "artist": artist,
                                    "duration": dur, "ms": int((time.time() - t0) * 1000)})
        return self._send(404, {"error": "not found"})


if __name__ == "__main__":
    print(f"rythmix-resolver :{PORT} key={'set' if API_KEY else 'open'} bgutil={BGUTIL}")
    HTTPServer(("0.0.0.0", PORT), H).serve_forever()
